# Slack Importer Skeleton (Offline, No API)

This skeleton provides the minimum code to import messages from a Slack export
(zip or directory) into the application **without using the Slack API**. The
importer reads JSON files exported from Slack (one per channel) and creates
Rooms and Messages in your Rails app.

## Contents

- `lib/imports/slack.rb` – top‑level namespace and autoloads
- `lib/imports/slack/parser.rb` – reads Slack export directory and yields
  channel name and message hashes
- `lib/imports/slack/importer.rb` – coordinates creation of Rooms and
  Messages; resolves users; wraps the operation in a transaction
- `lib/tasks/imports.rake` – Rake task `imports:slack` to trigger the import
- `app/models/current.rb` – extends `Current` to include an `importing`
  attribute (used to suppress push notifications during import)

## Usage

1. Ensure your Rails project has `app/models/current.rb` defining
   `class Current < ActiveSupport::CurrentAttributes`; merge the provided
   attribute `importing` if necessary.
2. Modify `app/models/message.rb` so that the `after_create_commit :push_later`
   callback only runs when `Current.importing` is **false**:

```ruby
after_create_commit :push_later, unless: -> { Current.respond_to?(:importing) && Current.importing }
```

3. Drop the `lib/imports` and `lib/tasks` files into your application. Rails
   will autoload these classes.
4. Run the Rake task to import your Slack export:

```sh
bin/rails imports:slack DATA_PATH=/path/to/slack/export USER_ID=1
```

   The optional `USER_ID` should refer to the local user who will own
   imported messages when a corresponding Slack user cannot be mapped. If
   omitted, the task will fall back to the first admin or first user.

## Notes

- The importer is intentionally simple. It reads only the `text` field from
  Slack messages and ignores threads, reactions, files or attachments. Future
  iterations can extend `Imports::Slack::Importer#build_body` to incorporate
  attachments or map Slack users using `users.json`.
- The import runs within a database transaction and sets `Current.importing` to
  `true` during the operation, ensuring push notifications and other side
  effects are suppressed.
- Ensure you have adequate indexing/validations on `Room` and `Message` models
  to handle potentially large imports gracefully.

