# frozen_string_literal: true

# Top level namespace for Slack import functionality.
#
# This module autoloads the parser and importer classes that encapsulate
# the behaviour for reading Slack export files and creating local data
# structures (rooms, messages, etc.) from them.  See
# `Imports::Slack::Parser` and `Imports::Slack::Importer` for details on
# usage.
module Imports
  module Slack
    autoload :Parser, 'imports/slack/parser'
    autoload :Importer, 'imports/slack/importer'
  end
end
