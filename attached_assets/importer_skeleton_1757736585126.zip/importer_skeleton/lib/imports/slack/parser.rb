# frozen_string_literal: true

require 'json'
require 'pathname'

module Imports
  module Slack
    # Parser reads a Slack export directory and yields structured channel
    # and message information. A Slack export is expected to be a directory
    # containing one JSON file per channel (e.g. `general.json`) plus
    # optional `users.json` and `channels.json` files. Each channel JSON
    # file is an array of messages as documented by Slack.
    #
    # The parser is intentionally simple and does not attempt to infer
    # semantics such as threads or reactions. Downstream importers can
    # decide what to do with the yielded objects.
    #
    # Example usage:
    #   parser = Imports::Slack::Parser.new('/path/to/export')
    #   parser.each_message do |channel_name, message|
    #     puts "#{channel_name}: #{message['user']}: #{message['text']}"
    #   end
    class Parser
      # @param export_path [String, Pathname] directory containing Slack export JSON
      def initialize(export_path)
        @export_path = Pathname.new(export_path.to_s)
      end

      # Iterates over each channel message in the export. For each yielded
      # message, the channel name and the raw hash from the Slack export
      # file are provided. Files that do not end with `.json` or are not
      # arrays of messages are ignored.
      #
      # @yield [channel_name, message] yields channel name and message hash
      def each_message
        channel_files.each do |file|
          channel_name = file.basename('.json').to_s
          messages = JSON.parse(file.read)
          next unless messages.is_a?(Array)

          messages.each do |message|
            yield channel_name, message
          end
        end
      end

      private

      # Returns an array of Pathname objects for each channel JSON file
      # in the export directory, excluding known metadata files.
      #
      # @return [Array<Pathname>]
      def channel_files
        @channel_files ||= begin
          Dir.children(@export_path).sort.filter_map do |entry|
            next if entry =~ /^(users|channels)\.json$/
            full_path = @export_path.join(entry)
            full_path if full_path.file? && full_path.extname == '.json'
          end
        end
      end
    end
  end
end
