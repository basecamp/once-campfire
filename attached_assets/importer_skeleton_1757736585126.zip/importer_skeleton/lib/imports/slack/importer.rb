# frozen_string_literal: true

require 'active_support/core_ext/string/inflections'
require 'active_support/core_ext/numeric/time'

module Imports
  module Slack
    # The Importer coordinates the process of reading a Slack export
    # directory via the Parser and creating corresponding Rooms, Users and
    # Messages within the application.  The aim of this class is to
    # perform an idempotent, minimal-first import. It does not attempt
    # to import files or threads; those are left for future iterations.
    class Importer
      # @param export_path [String] absolute or relative path to Slack export
      # @param current_user [User] user who will own messages when mapping cannot be determined
      def initialize(export_path, current_user:)
        @export_path = export_path
        @current_user = current_user
      end

      # Performs the import. This method wraps the operation in a
      # transaction so that partial imports do not leave the database in
      # an inconsistent state. It sets `Current.importing` around the
      # import to disable side effects such as push notifications.
      #
      # For each channel and message, a room is created (or found)
      # matching the channel name, and each message is persisted with
      # basic attributes (body, user, room, created_at). Unknown users
      # are mapped to the provided `current_user`.
      def import!
        parser = Parser.new(@export_path)

        ActiveRecord::Base.transaction do
          Current.importing = true
          parser.each_message do |channel_name, message_hash|
            import_message(channel_name, message_hash)
          end
        ensure
          Current.importing = false
        end
      end

      private

      # Imports a single message into the database.
      #
      # @param channel_name [String]
      # @param message_hash [Hash] raw Slack message data
      def import_message(channel_name, message_hash)
        room = find_or_create_room(channel_name)
        user = find_user_from_slack_id(message_hash['user'])
        timestamp = parse_ts(message_hash['ts'])
        body = build_body(message_hash)

        Message.create!(
          room: room,
          user: user || @current_user,
          body: body,
          created_at: timestamp,
          updated_at: timestamp
        )
      end

      # Finds or creates a room based on the Slack channel name. The
      # channel name is humanized and titleized to map to existing rooms.
      #
      # @param channel_name [String]
      # @return [Room]
      def find_or_create_room(channel_name)
        title = channel_name.to_s.tr('_', ' ').titleize
        Room.find_or_create_by!(name: title)
      end

      # Attempts to resolve a Slack user ID to a local user. If the
      # mapping cannot be found the importer returns nil and the caller
      # should substitute the `current_user` when creating the message.
      #
      # This default implementation returns nil for all unknown users.
      # Override this method to implement custom lookup behaviour,
      # e.g. by reading a `users.json` file or performing an email
      # match.
      #
      # @param slack_id [String, nil]
      # @return [User, nil]
      def find_user_from_slack_id(slack_id)
        return nil if slack_id.blank?
        # Example placeholder: lookup by an external_id column.
        User.find_by(external_id: slack_id)
      end

      # Parses the Slack timestamp (float seconds since epoch stored in a
      # string) into a Time instance. Returns current time if parsing
      # fails.
      #
      # @param ts [String]
      # @return [Time]
      def parse_ts(ts)
        Float(ts).then { |f| Time.at(f).utc } rescue Time.current
      end

      # Builds the message body from the Slack message hash. In this
      # minimal importer we simply take the `text` field. Future
      # iterations may augment this with files, attachments or
      # formatting.
      #
      # @param message_hash [Hash]
      # @return [String]
      def build_body(message_hash)
        message_hash['text'].to_s
      end
    end
  end
end
