# frozen_string_literal: true

# Current holds per-request state via ActiveSupport::CurrentAttributes.  A
# custom attribute `importing` is used to flag whether an import is
# currently running. When set to true, side effects such as push
# notifications should be disabled.
class Current < ActiveSupport::CurrentAttributes
  attribute :user
  # Flag indicating that a long-running import is in progress.
  attribute :importing, :boolean, default: false
end
